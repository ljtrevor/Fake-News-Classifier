import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileReader;
import java.util.Arrays;

import com.opencsv.CSVReader;
import org.apache.commons.lang3.StringUtils;

public class naiveBayes {
	
	public static List<String> vocabulary = new ArrayList<String>();
	public static List<Document> documents = new ArrayList<Document>();
	public static List<ClassLabel> classLabels = new ArrayList<ClassLabel>();
	public static int trueDocuments = 0;
	public static int falseDocuments = 0;
	
	/*[Creates list of document objects from realNews.csv]*/
	public static void getRealNews() {
		try {
			CSVReader reader = new CSVReader(new FileReader("realNews.csv"), ',' , '"' , 1);
			String[] nextLine;
			while ((nextLine = reader.readNext()) != null) {
				
				if (nextLine.length == 8) {
					documents.add(new Document(true, nextLine[0], nextLine[1], nextLine[2], nextLine[3], nextLine[4], nextLine[5], nextLine[6], nextLine[7]));
					trueDocuments++;
				}
			}
			reader.close();
		} catch(Exception e) {
			System.out.println(e);
			return;
		}
	}
	/*[End]*/
	
	/*[Creates list of document objects from fakeNews.csv]*/
	public static void getFakeNews() {
		try {
			CSVReader reader = new CSVReader(new FileReader("fakeNews.csv"), ',' , '"' , 1);
			String[] nextLine;
			while ((nextLine = reader.readNext()) != null) {
				
				if (nextLine.length == 20) {
					documents.add(new Document(false, nextLine[0], nextLine[2], nextLine[3], nextLine[4], nextLine[5], nextLine[7], nextLine[8], null));
					falseDocuments++;
				}
			}
			reader.close();
		} catch(Exception e) {
			System.out.println(e);
			return;
		}
	}
	/*[End]*/
	
	/*[Checks to see if term is a common term]*/
	public static boolean isStopWord(String possibleStopWord) {
		try {
			Scanner document = new Scanner(new File("stopWords.txt"));
			Scanner line = new Scanner(document.nextLine());
			
			while (document.hasNextLine()) {
				
				line = new Scanner(document.nextLine());
				while (line.hasNext()) {
					
					String term = line.next();
					term = term.toLowerCase();
					term = term.replaceAll("[^a-z]", "");
					if (term.equals(possibleStopWord)) {
						return true;
					}	
				}	
			}
			return false;
		} catch(Exception e) {
			System.out.println(e);
			return false;
		}
	}
	/*[End]*/
	
	/*[Creates dictionary by scanning document objects]*/
	public static void createVocabulary() {
		for (int i = 0; i < documents.size(); i++) {
				
			Scanner document = new Scanner(documents.get(i).getText());
			while (document.hasNextLine()) {
			
				Scanner line = new Scanner(document.nextLine());
				while (line.hasNext()) {
					
					String term = line.next();
					term = term.toLowerCase();
					term = term.replaceAll("[^a-z]", "");
					/*if (!isStopWord(term)) {*/
						boolean present = false;
						for (int j = 0; j < vocabulary.size(); j++) {
							
							if (vocabulary.get(j).equals(term)) {
								present = true;
								break;
							}
						}
						if (!present) {
							vocabulary.add(term);
						}
					/*}*/
				}	
			}
		}
	}
	/*[End]*/
	
	/*[Adds a true and false class label to classLabels]*/
	public static void configure() {
		classLabels.add(new ClassLabel(true, ((float)trueDocuments / documents.size())));
		classLabels.add(new ClassLabel(false, ((float)falseDocuments / documents.size())));
	}
	/*[End]*/
	
	/*[Iterates through vocabulary and sums the amount of times each term appears]*/
	public static void vocabulary(List<String> terms, int index) {
		int distinctTerms = 0;
		for (int i = 0; i < vocabulary.size(); i++) {
				
			String term  = vocabulary.get(i);
			int termAppearences = 0;
			for (int j = 0; j < terms.size(); j++) {
				
				if (terms.get(j).equals(term)) {
					if (termAppearences == 0) {
						distinctTerms++;
					}
					termAppearences++;
				}
				
			}
			classLabels.get(index).probability.put(term, ((float)(termAppearences + 1.00) / (terms.size() + vocabulary.size())));
		}
	}
	/*[End]*/
	
	/*[Calculates probability of terms appearing in documents]*/
	public static void calculateProbability() {
		for (int i = 0; i < classLabels.size(); i++) {
			List<String> terms = new ArrayList<String>();
			
			for (int j = 0; j < documents.size(); j++) {
				
				if (documents.get(j).getLabel() == classLabels.get(i).getLabel()) {
					Scanner document = new Scanner(documents.get(j).getText());
					while (document.hasNextLine()) {
					
						Scanner line = new Scanner(document.nextLine());
						while (line.hasNext()) {
							
							String term  = line.next();
							term = term.toLowerCase();
							term = term.replaceAll("[^a-z]", "");
							terms.add(term);
						}	
					}
				}
			}
			vocabulary(terms, i);
		}
	}
	/*[End]*/
	
	/*[Prints probabilites]*/
	public static void print() {
		for (int i = 0; i < classLabels.size(); i++) {
			
			for (int j = 0; j < vocabulary.size(); j++) {
			
				String term  = vocabulary.get(j);
				System.out.println("Class: " + classLabels.get(i).getLabel() + " |  Term: " + term + " |  Probability: " + classLabels.get(i).probability.get(term));
			}	
		}
	}
	/*[End]*/
	
	/*[Training]*/
	public static void train() {
		getRealNews();
		getFakeNews();
		createVocabulary();
		configure();
		calculateProbability();
	}
	/*[End]*/
	
	/*[Testing]*/
	public static void test(String fileName) {
		try {
			List<String> terms = new ArrayList<String>();
			Map<Boolean, Double> score = new HashMap<Boolean, Double>();
			Scanner document = new Scanner(new File(fileName));
			Scanner line = new Scanner(document.nextLine());
			
			while (document.hasNextLine()) {
				
				line = new Scanner(document.nextLine());
				while (line.hasNext()) {
					
					String term = line.next();
					term = term.toLowerCase();
					term = term.replaceAll("[^a-z]", "");
					for (int j = 0; j < vocabulary.size(); j++) {
						if (vocabulary.get(j).equals(term)) {
							terms.add(term);
							break;
						}
					}	
				}	
			}
			
			for (int i = 0; i < classLabels.size(); i++) {
				
				score.put(classLabels.get(i).getLabel(), Math.log(classLabels.get(i).getRatio()));
				for (int j = 0; j < terms.size(); j++) {
					
					score.put(classLabels.get(i).getLabel(), score.get(classLabels.get(i).getLabel()) + Math.log(classLabels.get(i).probability.get(terms.get(j))));
				}	
			}
			
			String output = fileName + " is classified as";
			double trueScore = score.get(true);
			double falseScore = score.get(false);
			
			System.out.println("true:" + trueScore);
			System.out.println("false: " + falseScore);
			
			if (trueScore > falseScore) {
				output = output + " real news";
			} else {
				output = output + " fake news";
			}
			System.out.println(output);
			
		} catch(Exception e) {
			System.out.println(e);
			return;
		}
	}
	/*[End]*/
		
	/*[Main]*/
	public static void main(String[] args) {
		train();
		for (int i = 0; i < args.length; i++) {
			test(args[i]);
		}
	}
	/*[End]*/
}

class Document {
   
	private boolean label;
	private String uuid;
	private String author;
	private String published;
	private String title;
	private String text;
	private String crawled;
	private String domain;
	private String URL;
   
	public Document(boolean label, String uuid, String author, String published, String title, String text, String crawled, String domain, String URL) {
		this.label = label;
		this.uuid = uuid;
	    this.author = author;
	    this.published = published;
	    this.title = title;
	    this.text = text;
	    this.crawled = crawled;
	    this.domain = domain;
	    this.URL = URL;	   
	}
   
	public boolean getLabel() {
		return label;
	}
    
	public String getText() {
		return text;
	}
   
	public String getDomain() {
		return domain;
	}
   
	public String getAuthor() {
		return author;
	}
}

class ClassLabel {
   
	private boolean label;
	private float ratio;
	public Map<String, Float> probability = new HashMap<String, Float>();
  
	public ClassLabel(boolean label, float ratio) {
		this.label = label;
		this.ratio = ratio;
	}
   
	public boolean getLabel() {
		return label;
	}  
   
	public float getRatio() {
		return ratio;
	}  
}